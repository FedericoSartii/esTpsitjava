public class Main {
    public static void main(String[] args) throws InterruptedException {

        int n = 8;
        int k = 3;

        Fattoriale t1 = new Fattoriale(n);
        Fattoriale t2 = new Fattoriale(k);
        Fattoriale t3 = new Fattoriale(n - k);


        t1.start();
        t2.start();
        t3.start();


        t1.join();
        t2.join();
        t3.join();


        long fattN = t1.getVal();
        long fattK = t2.getVal();
        long fattNK = t3.getVal();


        long risultato = fattN / (fattK * fattNK);


        System.out.println("Combinazioni di " + n + " e " + k + " = " + risultato);
    }
}